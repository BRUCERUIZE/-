package com.example.mybatisstudy02;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mybatisstudy02ApplicationTests {



}
