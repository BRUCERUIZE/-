package com.example.mybatisstudy02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mybatisstudy02Application {

    public static void main(String[] args) {
        SpringApplication.run(Mybatisstudy02Application.class, args);
    }

}
