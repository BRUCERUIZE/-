package com.example.mybatisstudy02.dao;

import com.example.mybatisstudy02.pojo.Student;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface StudentMapper {

    //查询所有的学生
//    @Select("select * from student")
    public List<Student> getStudents();

    public List<Student> getStudents2();
}
