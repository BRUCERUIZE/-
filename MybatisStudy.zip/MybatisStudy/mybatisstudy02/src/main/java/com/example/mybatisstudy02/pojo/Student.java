package com.example.mybatisstudy02.pojo;

import lombok.Data;
import org.apache.ibatis.type.Alias;

@Data
//@Alias("Student")
public class Student{

    private int id;
    private String name;

    //学生需要关联一个老师
    private Teacher teacher;

    private int tid;


}
