package com.example.mybatisstudy02.dao;

import com.example.mybatisstudy02.pojo.Teacher;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface TeacherMapper {

    @Select("select * from teacher where id =#{tid} ")
    Teacher getTeacher(@Param("tid") int id);

    public Teacher getTeachers(int id);

}
