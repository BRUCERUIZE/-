package com.example.mybatisstudy03.dao;



import com.example.mybatisstudy03.pojo.Student;
import com.example.mybatisstudy03.pojo.Teacher;

import java.util.List;

public interface StudentMapper {


}
