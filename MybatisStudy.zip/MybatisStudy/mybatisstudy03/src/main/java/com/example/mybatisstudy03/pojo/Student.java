package com.example.mybatisstudy03.pojo;

import lombok.Data;

@Data
//@Alias("Student")
public class Student{

    private int id;
    private String name;


    private int tid;


}
