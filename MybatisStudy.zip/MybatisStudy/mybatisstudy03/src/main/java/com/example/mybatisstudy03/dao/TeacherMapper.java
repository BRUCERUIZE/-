package com.example.mybatisstudy03.dao;


import com.example.mybatisstudy03.pojo.Student;
import com.example.mybatisstudy03.pojo.Teacher;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface TeacherMapper {

    //获取老师
    List<Teacher> getTeacher();

    //获取老师的所有学生
    Teacher getallStudent(@Param("tid") int id);

}
