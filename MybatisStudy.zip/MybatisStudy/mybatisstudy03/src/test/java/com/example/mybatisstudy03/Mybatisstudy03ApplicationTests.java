package com.example.mybatisstudy03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mybatisstudy03ApplicationTests {

    @Test
    void contextLoads() {
    }

}
