package com.example.mybatisstudy03;

import com.example.mybatisstudy03.dao.StudentMapper;
import com.example.mybatisstudy03.dao.TeacherMapper;
import com.example.mybatisstudy03.pojo.Teacher;
import com.example.mybatisstudy03.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;
import org.junit.jupiter.api.Test;

public class Mytest {
    @Test
    public void test() {
        SqlSession sqlSession = MybatisUtils.getSession();
        TeacherMapper mapper = sqlSession.getMapper(TeacherMapper.class);

        Teacher teacher = mapper.getallStudent(1);

        System.out.println(teacher);

        sqlSession.close();
    }
}
