package com.example.mybatisstudy05.pojo;

public class User {
    private int id;
    private String name;
    private String pwd;
}
