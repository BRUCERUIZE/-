package com.example.mybatisstudy04.dao;

import com.example.mybatisstudy04.pojo.Blog;
import jdk.internal.dynalink.linker.LinkerServices;

import java.util.List;
import java.util.Map;

public interface BlogMapper {
    //插入数据
    int addBlog(Blog blog);

    //查询博客
    List<Blog> queryBlogIF(Map map);

    List<Blog> queryBlogChoose(Map map);

    int updateBlog(Map map);

    List<Blog> queryBlogForeach(Map map);
}
