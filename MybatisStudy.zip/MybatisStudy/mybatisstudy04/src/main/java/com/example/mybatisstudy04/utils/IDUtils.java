package com.example.mybatisstudy04.utils;

import org.testng.annotations.Test;

import java.lang.annotation.Target;
import java.util.UUID;

public class IDUtils {

    public static String genId(){
        return UUID.randomUUID().toString().replaceAll("-","");
    }
    @Test
    public void test(){
        System.out.println(IDUtils.genId());
    }
}
