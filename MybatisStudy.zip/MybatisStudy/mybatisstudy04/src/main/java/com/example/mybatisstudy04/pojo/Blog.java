package com.example.mybatisstudy04.pojo;

import lombok.Data;

import java.util.Date;

@Data
public class Blog {
    private String id;
    private String title;
    private String author;
    private Date createTime;    //属性名和字段名不一样，可以转换，mapUnderscoreToCamelCase
    private int views;
    //set，get....
}
