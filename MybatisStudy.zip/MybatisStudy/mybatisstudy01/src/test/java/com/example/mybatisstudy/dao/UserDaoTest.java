package com.example.mybatisstudy.dao;

import com.example.mybatisstudy.pojo.User;
import com.example.mybatisstudy.utils.MybatisUtils;
import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.junit.Test;
import org.yaml.snakeyaml.Yaml;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class UserDaoTest {

    @Test
    public void selectUser() {
            //第一步：获得sqlsession对象
            SqlSession sqlsession = MybatisUtils.getSession();
            //方法一:getMapper
            //List<User> users = session.selectList("com.kuang.mapper.UserMapper.selectUser");
            //方法二:通过select具体的东西，限定死了方法，不推荐使用
            UserMapper mapper = sqlsession.getMapper(UserMapper.class);
            List<User> users = mapper.selectUser();

            for (User user: users){
                System.out.println(user);
            }
            sqlsession.close();
        }

    @Test
    public void getUserLike(){
        SqlSession sqlsession = MybatisUtils.getSession();
        UserMapper mapper = sqlsession.getMapper(UserMapper.class);

       List<User> userList = mapper.getUserLike("%李%");

        for (User user : userList) {
            System.out.println(user);

        }

        sqlsession.close();

    }

    @Test
    public void getUserById(){
        SqlSession sqlsession = MybatisUtils.getSession();
        UserMapper mapper = sqlsession.getMapper(UserMapper.class);

        User user = mapper.getUserById(1);
        System.out.println(user);
        sqlsession.close();
    }

    @Test
    public void getUserById2(){
        SqlSession sqlsession = MybatisUtils.getSession();
        UserMapper mapper = sqlsession.getMapper(UserMapper.class);

        HashMap<String, Object> map = new HashMap<>();
        map.put("id",1);
        mapper.getUserById2(map);

        sqlsession.close();
    }

    //增删改需要提交事务
    @Test
    public void addUser(){
        SqlSession sqlsession = MybatisUtils.getSession();
        UserMapper mapper = sqlsession.getMapper(UserMapper.class);
        int res = mapper.addUser(new User(4, "shanshan","123333"));
        if(res>0){
            System.out.println("插入成功！");
        }
        //提交事务
        sqlsession.commit();
        sqlsession.close();
    }

    @Test
    public void addUser2(){
        SqlSession sqlsession = MybatisUtils.getSession();
        UserMapper mapper = sqlsession.getMapper(UserMapper.class);

        HashMap<String, Object> map = new HashMap<>();

        map.put("userid",5);
        map.put("userName","Hello");
        map.put("password",555555);

        int res = mapper.addUser2(map);

        if(res>0){
            System.out.println("插入成功！");
        }
        //提交事务
        sqlsession.commit();
        sqlsession.close();
    }

    @Test
    public void updateUser(){
         SqlSession sqlsession = MybatisUtils.getSession();
         UserMapper userMapper = sqlsession.getMapper(UserMapper.class);
         int res = userMapper.updateUser(new User(2,"zeze","123456"));
        if(res>0){
            System.out.println("更新成功！");
        }
        //提交事务
        sqlsession.commit();
        sqlsession.close();
    }

    @Test
    public void deleteUser(){
            SqlSession sqlsession = MybatisUtils.getSession();
            UserMapper userMapper = sqlsession.getMapper(UserMapper.class);
            int res = userMapper.deleteUser(3);
            sqlsession.commit();
            sqlsession.close();
    }


    static Logger logger = Logger.getLogger(String.valueOf(UserDaoTest.class));

    @Test
    public void testLog4j(){
        logger.info("info：进入selectUser方法");
        logger.debug("debug：进入selectUser方法");
        logger.error("error: 进入selectUser方法");
        SqlSession session = MybatisUtils.getSession();
        UserMapper mapper = session.getMapper(UserMapper.class);
        List<User> users = mapper.selectUser();
        for (User user: users){
            System.out.println(user);
        }
        session.close();
    }

    @Test
    public void  getUserByLimit() {
        SqlSession sqlSession = MybatisUtils.getSession();
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);

        int currentPage = 1;  //第几页
        int pageSize = 2;  //每页显示几个
        Map<String,Integer> map = new HashMap<String,Integer>();

        map.put("startIndex",(currentPage-1)*pageSize);
        map.put("pageSize",pageSize);

        List<User> users = mapper.getUserByLimit(map);

        for (User user: users){
            System.out.println(user);
        }
        sqlSession.close();
    }

    @Test
    public void testUserByRowBounds() {
        SqlSession session = MybatisUtils.getSession();

        int currentPage = 2;  //第几页
        int pageSize = 2;  //每页显示几个
        RowBounds rowBounds = new RowBounds((currentPage-1)*pageSize,pageSize);

        //通过session.**方法进行传递rowBounds，[此种方式现在已经不推荐使用了]
        List<User> users = session.selectList("com.example.mybatisstudy.dao.UserMapper.getUserByRowBounds", null, rowBounds);

        for (User user: users){
            System.out.println(user);
        }
        session.close();
    }

    @Test
    public void getUsers(){
        SqlSession sqlSession = MybatisUtils.getSession();
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);
        List<User> users = mapper.getUsers();
        for (User user : users) {
            System.out.println(user);
        }

        sqlSession.close();
    }

    @Test
    public void getUserByID(){
        SqlSession sqlSession = MybatisUtils.getSession();
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);

        User user = mapper.getUserByID(9);

        System.out.println(user);

        sqlSession.close();
    }


    @Test
    public void AddUser(){

            SqlSession session = MybatisUtils.getSession();
            UserMapper mapper = session.getMapper(UserMapper.class);

            User user = new User(11, "秦疆", "123456");
            mapper.AddUser(user);
            session.close();

    }

    @Test
    public void UpDateUser(){
        SqlSession session = MybatisUtils.getSession();
        UserMapper mapper = session.getMapper(UserMapper.class);

        User user = new User(5, "qqqqq", "zxcvbn");
        mapper.UpDateUser(user);

        session.close();

    }

    @Test
    public void DeleteUser() {
        SqlSession session = MybatisUtils.getSession();
        UserMapper mapper = session.getMapper(UserMapper.class);

        mapper.DeleteUser(5);
        session.close();

    }
}

