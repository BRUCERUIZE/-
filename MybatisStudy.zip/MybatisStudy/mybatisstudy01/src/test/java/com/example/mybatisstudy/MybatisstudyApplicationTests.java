package com.example.mybatisstudy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybatisstudyApplicationTests {

    @Test
    void contextLoads() {
    }

}
