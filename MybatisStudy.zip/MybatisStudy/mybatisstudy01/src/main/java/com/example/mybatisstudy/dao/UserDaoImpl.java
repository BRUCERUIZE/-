package com.example.mybatisstudy.dao;

import com.example.mybatisstudy.pojo.User;

import java.util.List;
import java.util.Map;

public class UserDaoImpl implements UserMapper{


    @Override
    public List<User> selectUser() {
        return null;
    }

    @Override
    public List<User> getUsers() {
        return null;
    }

    @Override
    public User getUserByID(int id) {
        return null;
    }

    @Override
    public int AddUser(User user) {
        return 0;
    }

    @Override
    public int UpDateUser(User user) {
        return 0;
    }

    @Override
    public int DeleteUser(int id) {
        return 0;
    }


    @Override
    public List<User> getUserByLimit(Map<String, Integer> map) {
        return null;
    }

    @Override
    public List<User> getUserByRowBounds() {
        return null;
    }

    @Override
    public List<User> getUserLike(String value) {
        return null;
    }

    @Override
    public User getUserById(int id) {
        return null;
    }

    @Override
    public User getUserById2(Map<String, Object> map) {
        return null;
    }

    @Override
    public int addUser(User user) {
        return 0;
    }

    @Override
    public int addUser2(Map<String, Object> map) {
        return 0;
    }

    @Override
    public int updateUser(User user) {
        return 0;
    }

    @Override
    public int deleteUser(int id) {
        return 0;
    }
}
