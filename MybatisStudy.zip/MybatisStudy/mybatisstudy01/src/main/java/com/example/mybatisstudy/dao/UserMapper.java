package com.example.mybatisstudy.dao;

import com.example.mybatisstudy.pojo.User;
import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;

public interface UserMapper {
    //获取所有用户
    List<User> selectUser();

    @Select("select * from user")
    List<User> getUsers();

    //方法存在多个参数必须要加Param注解
    @Select("select * from user where id =#{id}")
    User getUserByID(@Param("id") int id);

    @Insert("insert into user (id,name,pwd) values (#{id},#{name},#{pwd})")
    int AddUser(User user);

    @Update("update user set name=#{name},pwd=#{pwd} where id = #{id}")
    int UpDateUser(User user);


    @Delete("delete from user where id=#{id}")
    int DeleteUser(@Param("id") int id);


    //分页
    List<User> getUserByLimit(Map<String,Integer> map);

    //RowBounds分页
    List<User> getUserByRowBounds();

    List<User> getUserLike(String value);

    //根据ID查询用户
    User getUserById(int id);


    User getUserById2(Map<String,Object> map);

    //增加用户
    int addUser(User user);

    //万能Map
    int addUser2(Map<String, Object>map);

    //修改用户
    int updateUser(User user);

    //删除用户
    int deleteUser(int id);
}
