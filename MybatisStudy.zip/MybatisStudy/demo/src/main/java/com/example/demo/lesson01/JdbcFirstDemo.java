package com.example.demo.lesson01;

import com.mysql.cj.jdbc.Driver;

import java.sql.*;

public class JdbcFirstDemo {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        //1.加载驱动
        DriverManager.registerDriver(new Driver());//注册驱动,会注册两次，赘余
        Class.forName("com.mysql.cj.jdbc.Driver");

        //2.用户信息和url
        String url = "jdbc:mysql://localhost:3306/jdbcstudy?useUnicode=true&characterEncoding=utf8&useSSL=true";
        String username = "root";
        String password = "123456";

        //3.连接成功，数据库对象 Connection代表数据库
        Connection connection = DriverManager.getConnection(url, username, password);

        /*
        connection 代表数据库
        事务提交connection.setAutoCommit(true);
        事务回滚connection.rollback();
        connection.commit();
        connection.getXXXX();
         */

        //4.执行SQL的对象 Statement执行sql对象
        Statement statement = connection.createStatement();
        /*
        statement.execute();//能执行任何的sql
        statement.executeQuery();//查询操作返回ResultSet结果集
        statement.executeUpdate();//更新插入删除都是这个，返回一个受影响的行数
         */

/**
 * 插入
 Statement st = connection.createStatement();
 String sql = "insert into user(..) values(..)";
 int num = st.executeUpdate(sql);
 if(num >0){
 System.out.println("插入成功！");
 }
 * 删除
 Statement st = connection.createStatement();
 String sql = "delete from user where id=1";
 int num = st.executeUpdate(sql);
 if(num >0){
 System.out.println("删除成功！");
 }
 * 修改
 Statement st = connection.createStatement();
 String sql = "update user set name = '' where name=''";
 int num = st.executeQuery(sql);
 if(num >0){
 System.out.println("修改成功！");
 }


 **/

        //5.执行SQL的对象去执行SQL，可能存在结果,查看返回结果
        String sql = "SELECT * FROM users";
        //statement.executeUpdate()增删改
        ResultSet resultSet = statement.executeQuery(sql);//ResultSet只有查询才有，返回的结果集,结果集中封装了我们全部的查询出来的结果
        /*
        resultSet.getObject();//不知道类型的情况下使用
        resultSet.getString();// 如果知道列的类型，这种情况下使用
        resultSet.getInt();
        resultSet.getFloat();
        resultSet.getDate();
        resultSet.beforeFirst();//指针最前
        resultSet.afterLast();//指针最后
         */
        resultSet.beforeFirst();//指针最前
        resultSet.afterLast();//指针最后

        while(resultSet.next()){
            System.out.println("id="+resultSet.getObject("id"));
            System.out.println("name="+resultSet.getObject("NAME"));
            System.out.println("password="+resultSet.getObject("PASSWORD"));
            System.out.println("email="+resultSet.getObject("email"));
            System.out.println("birthday="+resultSet.getObject("birthday"));
        }

        //6.释放链接
        resultSet.close();
        statement.close();
        connection.close();



    }



}
