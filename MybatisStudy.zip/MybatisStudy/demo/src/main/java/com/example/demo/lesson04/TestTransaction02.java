package com.example.demo.lesson04;

public class TestTransaction02 {
    /**
     * 编写连接时，实现一个接口DataSource
     * DBCP
     * C3P0
     * Druid:阿里巴巴
     *
     * 需要用到的jar包
     */


}
