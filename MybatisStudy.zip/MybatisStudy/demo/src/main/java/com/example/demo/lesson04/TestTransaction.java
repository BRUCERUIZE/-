package com.example.demo.lesson04;

import com.example.demo.lesson02.utils.JdbcUtils;

import java.sql.*;

public class TestTransaction {
    public static void main(String[] args) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            JdbcUtils.getConnection();
            //关闭数据库提交功能,自动会开启事务
            connection.setAutoCommit(false);

            String sql1 = "update account set money = money-100 where name = 'A'";
            connection.prepareStatement(sql1);
            statement.executeUpdate();
            String sql2 = "update account set money = money+100 where name = 'B'";
            statement.executeUpdate();

            //业务完毕 提交事务
            connection.commit();
            System.out.println("事务成功！");
        } catch (SQLException e) {
            try {
                connection.rollback();
                System.out.println("回滚");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        }finally {
            JdbcUtils.release(connection,statement,resultSet);
        }
    }
}
