package com.example.demo.lesson03;

import java.sql.*;

public class TestInsert {
    public static void main(String[] args) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = JdbcUtils.getConnection();
            //区别
            //使用问号占位符代替参数
            String sql ="INSERT INTO users(`id`,`NAME`,`PASSWORD`,`email`,`birthday`)VALUES(?,?,?,?)";
            /**
             * delete from users where id?
             *  "update Users set NAME = ? where id=? ;"
             */
            statement = connection.prepareStatement(sql);//预编译sql 先写sql 不执行
            //手动给参数赋值
            statement.setInt(1,4);
            statement.setString(2,"shanshan");
            statement.setString(3,"123456");
            statement.setString(4,"1295184078@qq.com");

            statement.executeUpdate(sql);
            int i = statement.executeUpdate(sql);
            if (i>0) {
                System.out.println("插入成功");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            com.example.demo.lesson02.utils.JdbcUtils.release(connection,statement,resultSet);
        }
    }
}
