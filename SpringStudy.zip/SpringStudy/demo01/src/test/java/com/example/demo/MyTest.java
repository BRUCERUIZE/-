package com.example.demo;

import com.example.demo.Service01.UserService;
import com.example.demo.Service01.UserServiceImpl;
import com.example.demo.config.ZCongfig;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import javax.annotation.Resource;

public class MyTest {
    public static void main(String[] args) {
//
//        //用户接触的是业务层，dao层他们不需要接触
//        //获取applicationcontext,拿到spring的容器
//        ApplicationContext context= new ClassPathXmlApplicationContext("beans.xml");
//        UserServiceImpl userService = (UserServiceImpl) context.getBean("UserServiceImpl");
//22
//        userService.getUser();
//
//
//        ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
//
//        Student student = (Student) context.getBean("student");
//        System.out.println(student.toString());
//    }
//
//    @Test
//    public void test2() {
//        ApplicationContext context = new ClassPathXmlApplicationContext("userbeans.xml");
//        User user = (User) context.getBean("user");
//        System.out.println(user.toString());
//
//    }
//    @Test
//    public void test3(){
//        ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
//        People people = context.getBean("people", People.class);
//        people.getCat().shout();
//        people.getDog().shout();
//    }
//
//    @Test
//    public void test4(){
//        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
//        User user = (User) context.getBean("user",User.class);
//
//        System.out.println(user.name);
//    }
//
//    @Test
//    public void test5(){
//        ApplicationContext context = new AnnotationConfigApplicationContext(ZCongfig.class);
//        User getUser = (User) context.getBean("getUser");
//        System.out.println(getUser.getName());
//    }
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        //动态代理代理的是接口
        UserService userService = (UserService) context.getBean("userService");

        userService.query();
    }
}
