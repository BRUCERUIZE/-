

function f(){
    var x = "var a=3 b=5; alert(a+b)"
    eval(x);
}