package com.example.demo.Service01;

public interface UserService {
    public void add();
    public void delete();
    public void update();
    public void query();
}
