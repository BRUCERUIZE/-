package com.example.demo.demo04;

import com.example.demo.demo02.UserService;
import com.example.demo.demo02.UserServiceImpl;

public class Client {
    public static void main(String[] args) {

        //真实角色
        UserServiceImpl userService = new UserServiceImpl();

        //代理角色
        ProxyInvocationHandler p = new ProxyInvocationHandler();

        //设置要代理的对象
        p.setTarget(userService);

        //动态生成代理类
        UserService proxy = (UserService) p.getProxy();

        proxy.add();
    }
}
