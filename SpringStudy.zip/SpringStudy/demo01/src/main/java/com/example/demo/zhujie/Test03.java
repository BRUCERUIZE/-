package com.example.demo.zhujie;

import java.lang.annotation.*;

//自定义注解
public class Test03 {
    @Myannotation2()
    public void test(){
    }

    @Myannotation3("shanshan")
    public void test2(){

    }
}



@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@interface Myannotation2{
    //注解的参数：参数类型+参数名（）；
    String name() default"";
    int age() default 0;
    int id() default -1;//如果默认值为-1代表不存在，indexof，如果找不到就返回-1
    String[] schools() default {"xibukaiyuan", "qinghuadaxue"};

}

@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@interface Myannotation3{
    String value();
}