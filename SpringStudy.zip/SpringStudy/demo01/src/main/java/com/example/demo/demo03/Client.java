package com.example.demo.demo03;

public class Client {
    public static void main(String[] args) {

        //真实角色
        Host host = new Host();

        //代理角色:现在是没有的,通过它来
        ProxyInvocationHandler p = new ProxyInvocationHandler();

        //通过调用程序处理角色来处理我们要调用的借口对象
        p.setRent(host);
        Rent proxy = (Rent) p.getProxy();
        proxy.rent();
    }
}