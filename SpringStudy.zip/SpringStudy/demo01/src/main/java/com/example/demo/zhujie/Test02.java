package com.example.demo.zhujie;

import java.lang.annotation.*;

public class Test02 {
    @MyAnnotation
    public void test(){

    }

    //定义一个注解
    //Target表示我们的注解可以用在什么地方
    @Target(value = {ElementType.METHOD, ElementType.TYPE})
    //Retention表示我们的注解在什么地方还有效果
    @Retention(RetentionPolicy.RUNTIME)
    //Documented是否将我们的注释生成载JAVAdoc中
    @Documented
    //Inherited 子类可以继承父类的注解
    @Inherited
    @interface MyAnnotation{

    }
}
