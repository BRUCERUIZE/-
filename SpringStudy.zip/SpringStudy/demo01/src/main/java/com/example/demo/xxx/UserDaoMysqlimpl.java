package com.example.demo;

public class UserDaoMysqlimpl implements UserDao{
    @Override
    public void getUser() {
        System.out.println("Mysql获取用户数据！");
    }
}
