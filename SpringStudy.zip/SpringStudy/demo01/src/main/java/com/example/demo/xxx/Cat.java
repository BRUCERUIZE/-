package com.example.demo;

public class Cat {
    public void shout(){
        System.out.println("miao");
    }
}
