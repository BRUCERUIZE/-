package com.example.demo.demo04;

import com.example.demo.demo03.Rent;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

//我们会用这个类来动态生成代理类
public class ProxyInvocationHandler implements InvocationHandler {
//proxy生成动态代理 invocationhandler调用处理程序的
    //被代理的接口，就是要做的事情
    private Object target;

    public void setTarget(Object target) {
        this.target = target;
    }

    /**
     *     生成得到代理类
     *     classloader 类的接口 invocationhandler
     */

    public Object getProxy() {
        return Proxy.newProxyInstance(this.getClass().getClassLoader(),
                                      target.getClass().getInterfaces(),
                                     this);
    }

    /**
     生成代理类,处理代理实例并返回结果
     */

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {

        //动态代理的本质就是使用反射机制实现
        //invoke(接口，方法)
        log(method.getName());
        Object result = method.invoke(target, args);

        return result;
    }
    public void log(String msg){
        System.out.println("执行了"+msg+"方法");
    }

}
