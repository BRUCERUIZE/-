package com.example.demo.zhujie;

import java.util.ArrayList;
import java.util.List;

public class Test01 extends Object{

    @Override
    public String toString(){
        return super.toString();
    }

    //已过时的，不推荐使用
    @Deprecated
    public static void test(){
        System.out.println("Deprecate");
    }
//镇压警告
    @SuppressWarnings("all")
    public void test02(){
        List list = new ArrayList();
    }
    public static void main(String[] args){
        test();
    }
}
