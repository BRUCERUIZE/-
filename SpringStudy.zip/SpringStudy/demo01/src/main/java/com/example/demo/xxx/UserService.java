package com.example.demo;

public interface UserService {
    void getUser();
}
