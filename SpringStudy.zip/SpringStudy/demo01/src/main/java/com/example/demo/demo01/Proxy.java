package com.example.demo.demo01;

public class Proxy implements Rent {

    private Host host;

    public Proxy() {
    }

    public Proxy(Host host) {
        this.host = host;
    }

    @Override
    public void rent() {
        host.rent();
        seeHouse();
        lease();
        fare();
    }

    public void seeHouse(){
        System.out.println("中介带你看房");
    }

    public void lease(){
        System.out.println("签合同");
    }

    public void fare(){
        System.out.println("收中介费");
    }
}
