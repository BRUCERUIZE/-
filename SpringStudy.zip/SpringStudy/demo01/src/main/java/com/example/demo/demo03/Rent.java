package com.example.demo.demo03;

//租房
public interface Rent {
    public void rent();
}
