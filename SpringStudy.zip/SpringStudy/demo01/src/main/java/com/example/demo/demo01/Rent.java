package com.example.demo.demo01;

public interface Rent {
    public void rent();
}
