package com.example.demo;

import org.springframework.scheduling.concurrent.ScheduledExecutorTask;

import java.security.SecureRandom;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class Address {
    private String address1;

    public String getAddress() { return address1; }

    public void setAddress(String address) {
        this.address1 = address;
    }
}
