package com.example.demo.fanshe;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

//动态创建对象，通过反射
public class Test09 {
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException, NoSuchFieldException {
        //获得Class对象
        Class c1 = Class.forName("com.example.demo.fanshe.User");

//        //构造一个对象
//        User user  = (User) c1.newInstance();//本质上使用了类的无参构造器
//        System.out.println(user);

        //通过构造器创建对象
        Constructor constructor = c1.getDeclaredConstructor(String.class, int.class, int.class);
        User user2 = (User) constructor.newInstance("shanshan", 001, 18);
        System.out.println(user2);

        //通过反射调用普通方法
        User user3 = (User)c1.newInstance();

        //通过反射获取一个方法
        //invoke(对象，"对象的值")
        Method setName = c1.getDeclaredMethod("setName", String.class);
        setName.invoke(user3,"shanshan");
        System.out.println(user3.getName());

        //通过反射操作属性
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++");
        User user4 = (User) c1.newInstance();
        Field name = c1.getDeclaredField("name");

        /*
          因为private修饰了的值不能直接访问，Class com.example.demo.fanshe.Test09 can not access
          a member of class com.example.demo.fanshe.User with modifiers "private"
          at sun.reflect.Reflection.ensureMemberAccess(Reflection.java:102)
          Method和Field，Constructor都有setAccessible方法 name.setAccessible(true)通过这个关掉安全监测
         */

        name.setAccessible(true);
        name.set(user4,"zeze");
        System.out.println(user4.getName());
    }
}
