package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;



//@Component组件 等价于<bean id="user" class="com.example.demo.User">
//@Component
//@Scope("prototype")
//@Scope("prototype") 相当于<bean scope="prototype"/>
@Component
public class User {
    private String name;

    public String getName() {
        return name;
    }

    @Value("shanshan")//注入值
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                '}';
    }
//   @Value("") 相当于<property name="name" value="shanshan"/>
//    @Value("shanshan")
//    public String name;
//    public String name = "珊珊";
}
//    private String name;
//    private int age;
//
//    public User() {
//    }
//
//    public User(String name, int age) {
//        this.name = name;
//        this.age = age;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public int getAge() {
//        return age;
//    }
//
//    public void setAge(int age) {
//        this.age = age;
//    }
//
//    @Override
//    public String toString() {
//        return "User{" +
//                "name='" + name + '\'' +
//                ", age=" + age +
//                '}';
//    }

