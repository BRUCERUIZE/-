package com.example.demo;

public class Dog {
    public void shout(){
        System.out.println("wwww");
    }
}
