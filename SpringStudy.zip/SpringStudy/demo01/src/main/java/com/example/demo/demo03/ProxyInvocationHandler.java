package com.example.demo.demo03;

import sun.text.resources.cldr.om.FormatData_om;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ResourceBundle;

//我们会用这个类来动态生成代理类
public class ProxyInvocationHandler implements InvocationHandler {

    //被代理的接口，就是要做的事情
    private Rent rent;
    public void setRent(Rent rent) {
        this.rent = rent;
    }

    //生成得到代理类
    //classloader 类的接口 invocationhandler
    public Object getProxy() {
        return Proxy.newProxyInstance(this.getClass().getClassLoader(),
                                      rent.getClass().getInterfaces(),
                                     this);
    }
    //生成代理类,处理代理实例并返回结果
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {

        //动态代理的本质就是使用反射机制实现
        //invoke(接口，方法)
        Object result = method.invoke(rent, args);
        seehouse();
        fare();
        return result;
    }
    public void seehouse(){
        System.out.println("中介带着看房");
    }
    public void fare(){
        System.out.println("收中介费");
    }

}
