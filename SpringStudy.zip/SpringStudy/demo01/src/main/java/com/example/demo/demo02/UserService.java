package com.example.demo.demo02;

public interface UserService {
    public void add();
    public void delete();
    public void update();
    public void query();
}
