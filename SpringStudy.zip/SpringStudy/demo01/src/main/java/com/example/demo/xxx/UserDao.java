package com.example.demo;

public interface UserDao {
    void getUser();
}
