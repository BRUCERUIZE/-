package com.example.demo03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo03ApplicationTests {

    @Test
    void contextLoads() {
    }

}
